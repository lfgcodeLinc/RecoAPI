package com.perples.recosample;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends Activity {
	public static final String RECO_UUID = "24DDF4118CF1440C87CDE368DAF9C93E";
	private static final int REQUEST_ENABLE_BT = 1;
	
	private BluetoothManager mBluetoothManager;
	private BluetoothAdapter mBluetoothAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
		mBluetoothAdapter = mBluetoothManager.getAdapter();
		
		if(mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
			Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableBTIntent, REQUEST_ENABLE_BT);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
			finish();
			return;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	protected void onResume() {
		Log.i("MainActivity", "onResume()");
		super.onResume();
		
		if(this.isBackgroundMonitoringServiceRunning(this)) {
			Switch swc = (Switch)findViewById(R.id.backgroundMonitoringSwitch);
			swc.setChecked(true);
		}
		
		if(this.isBackgroundRangingServiceRunning(this)) {
			Switch swc = (Switch)findViewById(R.id.backgroundRangingSwitch);
			swc.setChecked(true);
		}
	}

	@Override
	protected void onDestroy() {
		Log.i("MainActivity", "onDestroy");
		super.onDestroy();
	}
	
	public void onMonitoringSwitchClicked(View v) {
		Switch swc = (Switch)v;
		if(swc.isChecked()) {
			Log.i("MainActivity", "onMonitoringSwitchClicked off to on");
			Intent intent = new Intent(this, RECOBackgroundMonitoringService.class);
			startService(intent);
		} else {
			Log.i("MainActivity", "onMonitoringSwitchClicked on to off");
			stopService(new Intent(this, RECOBackgroundMonitoringService.class));
		}
	}
	
	public void onRangingSwitchClicked(View v) {
		Switch swc = (Switch)v;
		if(swc.isChecked()) {
			Log.i("MainActivity", "onRangingSwitchClicked off to on");
			startService(new Intent(this, RECOBackgroundRangingService.class));
		} else {
			Log.i("MainActivity", "onRangingSwitchClicked on to off");
			stopService(new Intent(this, RECOBackgroundRangingService.class));
		}
	}
	
	public void onButtonClicked(View v) {
		Button btn = (Button)v;
		if(btn.getId() == R.id.monitoringButton) {
			final Intent intent = new Intent(this, RECOMonitoringActivity.class);
			startActivity(intent);
		} else {
			final Intent intent = new Intent(this, RECORangingActivity.class);
			startActivity(intent);
		}
	}
	
	private boolean isBackgroundMonitoringServiceRunning(Context context) {
		ActivityManager am = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		for(RunningServiceInfo runningService : am.getRunningServices(Integer.MAX_VALUE)) {
			if(RECOBackgroundMonitoringService.class.getName().equals(runningService.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	
	private boolean isBackgroundRangingServiceRunning(Context context) {
		ActivityManager am = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		for(RunningServiceInfo runningService : am.getRunningServices(Integer.MAX_VALUE)) {
			if(RECOBackgroundRangingService.class.getName().equals(runningService.service.getClassName())) {
				return true;
			}
		}
		return false;
	}

}
