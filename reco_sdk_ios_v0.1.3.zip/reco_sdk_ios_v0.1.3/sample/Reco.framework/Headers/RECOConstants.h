//
//  RECOConstants.h
//  Copyright (c) 2014 Perples. All rights reserved.
//

#ifndef reco_sdk_RECOConstants_h
#define reco_sdk_RECOConstants_h

static NSString * const kRECOProximityUUID = @"24DDF411-8CF1-440C-87CD-E368DAF9C93E";
static NSString * const version = @"0.1.3";
#endif
