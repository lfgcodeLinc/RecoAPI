//
//  AppDelegate.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, assign) BOOL isBackgroundMonitoringOn;

- (void) startBackgroundMonitoring;
- (void) stopBackgroundMonitoring;

@end
