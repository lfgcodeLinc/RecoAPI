//
//  MainViewController.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Reco/Reco.h>

@interface MainViewController : UIViewController <RECOBeaconManagerDelegate>

@property (nonatomic, strong) IBOutlet UISwitch *bSwitch;

@end
