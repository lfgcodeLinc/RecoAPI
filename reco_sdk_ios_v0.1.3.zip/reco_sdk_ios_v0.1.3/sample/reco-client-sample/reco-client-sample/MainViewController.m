//
//  MainViewController.m
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import "MainViewController.h"
#import "AppDelegate.h"

@interface MainViewController ()

@end

@implementation MainViewController {
    RECOBeaconManager *_recoManager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    if (appDelegate.isBackgroundMonitoringOn) {
        [self.bSwitch setOn:YES];
    }
    
    _recoManager = [[RECOBeaconManager alloc] init];
    _recoManager.delegate = self;
    [_recoManager requestAlwaysAuthorization];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)didChangeSwitchState:(id)sender {
    UISwitch *bSwitch = (UISwitch *)sender;
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    if (bSwitch.on) {
        [appDelegate startBackgroundMonitoring];
    } else {
        [appDelegate stopBackgroundMonitoring];
    }
}

- (void)recoManager:(RECOBeaconManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
}

@end
