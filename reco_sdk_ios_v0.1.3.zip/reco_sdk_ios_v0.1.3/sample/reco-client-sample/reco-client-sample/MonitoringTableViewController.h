//
//  MonitoringTableViewController.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Reco/Reco.h>

@interface MonitoringTableViewController : UITableViewController <UITableViewDataSource, RECOBeaconManagerDelegate>

@end
