//
//  NavigationViewController.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationViewController : UINavigationController

@end
