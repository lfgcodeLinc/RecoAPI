//
//  RangedBeaconViewController.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Reco/Reco.h>

@interface RangedBeaconViewController : UIViewController

@property (nonatomic, strong) RECOBeacon *beacon;
@property (nonatomic, strong) IBOutlet UILabel *state;

@end
