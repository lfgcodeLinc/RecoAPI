//
//  RangedBeaconViewController.m
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import "RangedBeaconViewController.h"

@interface RangedBeaconViewController ()

@property (nonatomic, strong) IBOutlet UILabel *uuid;
@property (nonatomic, strong) IBOutlet UILabel *major;
@property (nonatomic, strong) IBOutlet UILabel *minor;
@property (nonatomic, strong) IBOutlet UILabel *rssi;
@property (nonatomic, strong) IBOutlet UILabel *accuracy;

@end

@implementation RangedBeaconViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.uuid setText:[self.beacon.proximityUUID UUIDString]];
    [self.major setText:[self.beacon.major stringValue]];
    [self.minor setText:[self.beacon.minor stringValue]];
    [self.rssi setText:[NSString stringWithFormat:@"%ld", (long)self.beacon.rssi]];
    [self.accuracy setText:[NSString stringWithFormat:@"%.4fm", self.beacon.accuracy]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
