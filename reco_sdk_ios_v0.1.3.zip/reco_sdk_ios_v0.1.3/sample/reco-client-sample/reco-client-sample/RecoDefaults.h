//
//  RecoDefaults.h
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecoDefaults : NSObject

+ (RecoDefaults *)sharedDefaults;

@property (nonatomic, copy, readonly) NSArray *supportedUUIDs;

@end
