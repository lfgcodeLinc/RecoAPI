//
//  RecoDefaults.m
//
//  Copyright (c) 2014 Perples. All rights reserved.
//

#import "RecoDefaults.h"

@implementation RecoDefaults

- (id)init {
    self = [super init];
    if(self) {
        // this is RECO beacon uuid
        _supportedUUIDs = @[
                            [[NSUUID alloc] initWithUUIDString:@"24DDF411-8CF1-440C-87CD-E368DAF9C93E"]
                            // you can add other NSUUID instance here.
                            ];
    }
    return self;
}


+ (RecoDefaults *)sharedDefaults {
    static id sharedDefaults = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedDefaults = [[self alloc] init];
    });
    
    return sharedDefaults;
}

@end
